package discoveryservernew;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryServerNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
